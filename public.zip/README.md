npx hardhat compile
npx hardhat run --network sepolia scripts/deploy.js
